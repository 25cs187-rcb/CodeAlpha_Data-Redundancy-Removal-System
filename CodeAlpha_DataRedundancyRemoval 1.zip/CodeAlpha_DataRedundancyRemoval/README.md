# CodeAlpha_DataRedundancyRemoval

**Task 1 — Data Redundancy Removal System**
CodeAlpha Cloud Computing Internship

## What it does
A small Flask service that classifies every incoming record as:

| Classification   | Meaning                                                              |
|-------------------|-----------------------------------------------------------------------|
| `UNIQUE`          | Genuinely new record — gets appended to the database                 |
| `DUPLICATE`       | Exact or near-exact match of an existing record — rejected            |
| `FALSE_POSITIVE`  | Superficially similar to an existing record but distinct — kept out of the duplicate bucket, flagged for review |

Matching uses two layers:
1. **Exact match** — SHA-256 hash of a normalized `name|email|phone` fingerprint.
2. **Fuzzy match** — `difflib.SequenceMatcher` similarity ratio against every
   stored fingerprint, split at two thresholds (`DUPLICATE_THRESHOLD = 0.92`,
   `REVIEW_THRESHOLD = 0.75`).

Only records classified `UNIQUE` are ever written to the database, which
directly satisfies "prevent duplicate data from being added" and "append
only unique and verified data entries."

## Run it

```bash
pip install -r requirements.txt
python app.py
```

## API

- `POST /records` — submit `{ "name": "...", "email": "...", "phone": "..." }`.
  Classifies the record; stores it only if `UNIQUE`.
- `POST /records/check` — same as above but never writes to the DB (dry run).
- `GET /records` — list all stored (unique) records.
- `GET /health` — health check for load balancers / uptime monitors.

## Example

```bash
curl -X POST http://localhost:5000/records \
  -H "Content-Type: application/json" \
  -d '{"name":"Asha Rao","email":"asha@example.com","phone":"9876543210"}'

curl -X POST http://localhost:5000/records \
  -H "Content-Type: application/json" \
  -d '{"name":"Asha Rao","email":"asha@example.com","phone":"9876543210"}'
# -> classified as DUPLICATE
```

## Deploying to the cloud
This is a plain WSGI app — run it behind `gunicorn app:app` on any of
AWS Elastic Beanstalk / EC2, Azure App Service, Google Cloud Run, or
Render/Heroku. Swap the SQLite file for a managed database (RDS,
Cloud SQL, Azure SQL) once you need multi-instance scaling.
