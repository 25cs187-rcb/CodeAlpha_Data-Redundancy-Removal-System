"""
CodeAlpha - Task 1: Data Redundancy Removal System
----------------------------------------------------
A cloud-ready service that classifies incoming records as:
  - DUPLICATE       -> exact match already exists
  - FALSE_POSITIVE  -> looks similar but is actually a distinct record
                       (similarity above a "review" threshold but below
                        the "duplicate" threshold, and key fields differ)
  - UNIQUE          -> genuinely new, gets appended to the database

Run locally:
    pip install -r requirements.txt
    python app.py
Then POST records to http://localhost:5000/records

Deploying to the cloud (AWS/Azure/GCP/Render/Heroku):
  - This is a standard WSGI Flask app, so it can run behind gunicorn:
        gunicorn app:app
  - Swap SQLite for a managed DB (RDS / Cloud SQL / Azure SQL) by changing
    DB_PATH to a full SQLAlchemy-style connection if you outgrow SQLite.
"""

import sqlite3
import hashlib
import difflib
from datetime import datetime
from flask import Flask, request, jsonify

app = Flask(__name__)
DB_PATH = "records.db"

# Similarity thresholds (0..1) using difflib's SequenceMatcher on a
# normalized "fingerprint" string built from the record's key fields.
DUPLICATE_THRESHOLD = 0.92      # near-identical -> treat as duplicate
REVIEW_THRESHOLD = 0.75         # similar but not identical -> false positive


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            phone TEXT,
            fingerprint TEXT,
            hash TEXT UNIQUE,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def normalize(record: dict) -> str:
    """Build a normalized fingerprint string from the record's key fields."""
    name = (record.get("name") or "").strip().lower()
    email = (record.get("email") or "").strip().lower()
    phone = "".join(ch for ch in (record.get("phone") or "") if ch.isdigit())
    return f"{name}|{email}|{phone}"


def record_hash(fingerprint: str) -> str:
    return hashlib.sha256(fingerprint.encode()).hexdigest()


def classify(record: dict):
    """
    Compare the incoming record's fingerprint against every stored
    fingerprint and return (classification, best_match_row_or_None, score).
    """
    fingerprint = normalize(record)
    exact_hash = record_hash(fingerprint)

    conn = get_db()
    existing = conn.execute("SELECT * FROM records").fetchall()

    # 1. Exact hash match -> definite duplicate, no need to scan further.
    for row in existing:
        if row["hash"] == exact_hash:
            conn.close()
            return "DUPLICATE", dict(row), 1.0

    # 2. Fuzzy match against all existing fingerprints.
    best_score = 0.0
    best_row = None
    for row in existing:
        score = difflib.SequenceMatcher(None, fingerprint, row["fingerprint"]).ratio()
        if score > best_score:
            best_score = score
            best_row = row

    conn.close()

    if best_score >= DUPLICATE_THRESHOLD:
        return "DUPLICATE", dict(best_row), best_score
    elif best_score >= REVIEW_THRESHOLD:
        # Similar enough to flag for review, but key identifying fields
        # (email or phone) differ, so we treat it as a false positive
        # rather than blocking a legitimately distinct record.
        return "FALSE_POSITIVE", dict(best_row), best_score
    else:
        return "UNIQUE", None, best_score


@app.route("/records", methods=["POST"])
def add_record():
    """
    Validate + classify a new record. Only UNIQUE records are appended.
    Body JSON: {"name": "...", "email": "...", "phone": "..."}
    """
    data = request.get_json(silent=True) or {}
    if not any(data.get(f) for f in ("name", "email", "phone")):
        return jsonify({"error": "Provide at least one of name, email, phone"}), 400

    classification, match, score = classify(data)

    result = {
        "classification": classification,
        "similarity_score": round(score, 3),
        "matched_existing_record": match,
    }

    if classification == "UNIQUE":
        fingerprint = normalize(data)
        conn = get_db()
        conn.execute(
            "INSERT INTO records (name, email, phone, fingerprint, hash, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                data.get("name"),
                data.get("email"),
                data.get("phone"),
                fingerprint,
                record_hash(fingerprint),
                datetime.utcnow().isoformat(),
            ),
        )
        conn.commit()
        new_id = conn.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
        conn.close()
        result["stored"] = True
        result["record_id"] = new_id
    else:
        result["stored"] = False

    return jsonify(result), 201 if classification == "UNIQUE" else 200


@app.route("/records", methods=["GET"])
def list_records():
    conn = get_db()
    rows = [dict(r) for r in conn.execute("SELECT id, name, email, phone, created_at FROM records").fetchall()]
    conn.close()
    return jsonify({"count": len(rows), "records": rows})


@app.route("/records/check", methods=["POST"])
def check_record():
    """Dry-run classification without inserting anything."""
    data = request.get_json(silent=True) or {}
    classification, match, score = classify(data)
    return jsonify({
        "classification": classification,
        "similarity_score": round(score, 3),
        "matched_existing_record": match,
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
